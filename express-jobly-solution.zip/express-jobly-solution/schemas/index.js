exports.companyNewSchema = require("./companyNew");
exports.companyUpdateSchema = require("./companyUpdate");
exports.jobNewSchema = require("./jobNew");
exports.jobUpdateSchema = require("./jobUpdate");
exports.userAuthSchema = require("./userAuth");
exports.userNewSchema = require("./userNew");
exports.userUpdateSchema = require("./userUpdate");
